<?php
ob_start();
session_start();
include("../../admin/inc/config.php");
include("../../admin/inc/functions.php");
// Getting all language variables into array as global variable
$i=1;
$statement = $pdo->prepare("SELECT * FROM tbl_language");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                           
foreach ($result as $row) {
    define('LANG_VALUE_'.$i,$row['lang_value']);
    $i++;
}
?>

<?php require 'lib/init.php'; ?>

<?php

$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
foreach ($result as $row) {
    $stripe_public_key = $row['stripe_public_key'];
    $stripe_secret_key = $row['stripe_secret_key'];
}

if (isset($_POST['payment']) && $_POST['payment'] == 'posted' && floatval($_POST['amount']) > 0 && isset($_POST['shipping']) && isset($_POST['commission'])) {

    \Stripe\Stripe::setApiKey($stripe_secret_key);
    try {
        if (!isset($_POST['stripeToken']))
            throw new Exception("The Stripe Token was not generated correctly");

        $payment_date = date('Y-m-d H:i:s');
        $payment_id = time();
        $amount = floatval($_POST['amount']);
        $cents = floatval($amount * 100); //converting to cents

        $response = \Stripe\Charge::create(array(
                    "amount" => $cents,
                    "currency" => "usd",
                    "card" => $_POST['stripeToken'],
                    //"receipt_email" => $_POST['customer_email'],
                    "description" => 'Stripe Test Payment'
        ));

        $transaction_id = $response->id; // Its unique charge ID

        $statement = $pdo->prepare("SELECT * FROM tbl_payment WHERE txnid=?");
        $statement->execute(array($transaction_id));
        $total = $statement->rowCount();
        if($total>0) {
            echo '<script type="text/javascript">alert("Error: Transaction Number Used Already");
                window.open("'.BASE_URL.'checkout.php","_self");
            </script>';
        }

        $transaction_status = $response->status;
        $statement = $pdo->prepare("INSERT INTO tbl_payment (   
                                customer_id,
                                customer_name,
                                customer_email,
                                payment_date,
                                txnid, 
                                paid_amount,
                                paid_shipping,
                                paid_commission,
                                card_number,
                                card_cvv,
                                card_month,
                                card_year,
                                bank_transaction_info,
                                payment_method,
                                payment_status,
                                payment_id,
                                parcel_count
                            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $statement->execute(array(
                                $_SESSION['customer']['cust_id'],
                                $_SESSION['customer']['cust_name'],
                                $_SESSION['customer']['cust_email'],
                                $payment_date,
                                $transaction_id,
                                $_POST['amount'],
                                $_POST['shipping'],
                                $_POST['commission'],
                                $_POST['card_number'], 
                                $_POST['card_cvv'], 
                                $_POST['card_month'], 
                                $_POST['card_year'],
                                '',
                                'Stripe',
                                'Completed',
                                $payment_id,
                                ''
                            ));

        $i=0;
        foreach($_SESSION['cart_p_id'] as $key => $value) 
        {
            $i++;
            $arr_cart_p_id[$i] = $value;
        }

        $i=0;
        foreach($_SESSION['cart_p_name'] as $key => $value) 
        {
            $i++;
            $arr_cart_p_name[$i] = $value;
        }

        $i=0;
        foreach($_SESSION['cart_size_name'] as $key => $value) 
        {
            $i++;
            $arr_cart_size_name[$i] = $value;
        }

        $i=0;
        foreach($_SESSION['cart_color_name'] as $key => $value) 
        {
            $i++;
            $arr_cart_color_name[$i] = $value;
        }

        $i=0;
        foreach($_SESSION['cart_p_qty'] as $key => $value) 
        {
            $i++;
            $arr_cart_p_qty[$i] = $value;
        }

        $i=0;
        foreach($_SESSION['cart_p_current_price'] as $key => $value) 
        {
            $i++;
            $arr_cart_p_current_price[$i] = $value;
        }

        $i=0;
        foreach($_SESSION['cart_cust_val'] as $key => $value) 
        {
            $i++;
            $arr_cart_cust_val[$i] = $value;
        }
                
        $i=0;
        foreach($_SESSION['cart_p_type'] as $val) {
            $i++;
            $arr_cart_p_type[$i] = $value;
        }

        $i=0;
        $statement = $pdo->prepare("SELECT * FROM tbl_product");
        $statement->execute();
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);                           
        foreach ($result as $row) {
            $i++;
            $arr_p_id[$i] = $row['p_id'];
            $arr_p_qty[$i] = $row['p_qty'];
        }

        for($i=1;$i<=count($arr_cart_p_name);$i++) {
                    $statement = $pdo->prepare("INSERT INTO tbl_order (
                                    order_date,
                                    product_id,
                                    product_name,
                                    size, 
                                    color,
                                    custom,
                                    quantity, 
                                    unit_price, 
                                    product_comment,
                                    payment_id,
                                    product_link,
                                    product_china_code,
                                    product_china_status,
                                    product_china_receive_date,
                                    product_site_track,
                                    product_shipping_status,
                                    order_notes
                                    ) 
                                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                    $sql = $statement->execute(array(
                                    time(),
                                    (($arr_cart_p_type[$i] == 0) ? $arr_cart_p_id[$i] : -1),
                                    $arr_cart_p_name[$i],
                                    $arr_cart_size_name[$i],
                                    $arr_cart_color_name[$i],
                                    (($arr_cart_cust_val[$i]['custom'] == null) ? "" : $arr_cart_cust_val[$i]['custom']),
                                    $arr_cart_p_qty[$i],
                                    $arr_cart_p_current_price[$i],
                                    (($arr_cart_cust_val[$i]['comment'] == null) ? "" : $arr_cart_cust_val[$i]['comment']),
                                    $payment_id,
                                    (($arr_cart_cust_val[$i]['link'] == null) ? "" : $arr_cart_cust_val[$i]['link']),
                                    '',
                                    0,
                                    '',
                                    '',
                                    '',
                                    ''
                                ));

            // Update the stock
            for($j=1;$j<=count($arr_p_id);$j++)
            {
                if($arr_p_id[$j] == $arr_cart_p_id[$i]) 
                {
                    $current_qty = $arr_p_qty[$j];
                    break;
                }
            }
            $final_quantity = $current_qty - $arr_cart_p_qty[$i];
            $statement = $pdo->prepare("UPDATE tbl_product SET p_qty=? WHERE p_id=?");
            $statement->execute(array($final_quantity,$arr_cart_p_id[$i]));
        }
        unset($_SESSION['cart_p_id']);
        unset($_SESSION['cart_size_id']);
        unset($_SESSION['cart_size_name']);
        unset($_SESSION['cart_color_id']);
        unset($_SESSION['cart_color_name']);
        unset($_SESSION['cart_cust_val']);
        unset($_SESSION['cart_p_type']);
        unset($_SESSION['cart_p_qty']);
        unset($_SESSION['cart_p_current_price']);
        unset($_SESSION['cart_p_name']);
        unset($_SESSION['cart_p_featured_photo']);

        if(isset($_SESSION['customer']))store_cart($pdo);

        header('location: ../../payment_success.php');

    } catch (Exception $e) {
        $error = $e->getMessage();
        ?><script type="text/javascript">alert('Error: <?php echo $error; ?>');
            window.open('<?php echo BASE_URL; ?>checkout.php','_self');
        </script><?php
    }
}else{
    header('location: ../../checkout.php');
    exit;
}
?>