<?php require_once('header.php'); ?>

<section class="content-header">
	<h1>Dashboard</h1>
</section>

<?php
	$statement = $pdo->prepare("SELECT * FROM tbl_top_category");
	$statement->execute();
	$total_top_category = $statement->rowCount();

	$statement = $pdo->prepare("SELECT * FROM tbl_mid_category");
	$statement->execute();
	$total_mid_category = $statement->rowCount();

	$statement = $pdo->prepare("SELECT * FROM tbl_end_category");
	$statement->execute();
	$total_end_category = $statement->rowCount();

	$statement = $pdo->prepare("SELECT * FROM tbl_product");
	$statement->execute();
	$total_product = $statement->rowCount();

	$statement = $pdo->prepare("SELECT * FROM tbl_payment WHERE payment_status=?");
	$statement->execute(array('Completed'));
	$total_order_completed = $statement->rowCount();

	$statement = $pdo->prepare("SELECT * FROM tbl_order WHERE product_china_status=?");
	$statement->execute(array('1'));
	$total_shipping_completed = $statement->rowCount();

	$statement = $pdo->prepare("SELECT * FROM tbl_payment WHERE payment_status=?");
	$statement->execute(array('Pending'));
	$total_order_pending = $statement->rowCount();

	$statement = $pdo->prepare("SELECT * FROM tbl_customer");
	$statement->execute(array());
	$total_users = $statement->rowCount();
	
    $statement1 = $pdo->prepare("SELECT order_id FROM tbl_notes WHERE status=? AND sender=?");
    $statement1->execute(array(0,2));
	$totalNotes = $statement1->rowCount();
	
  $timestamp = strtotime('yesterday midnight');
	$statement = $pdo->prepare("SELECT * FROM tbl_order WHERE product_china_status=? AND product_china_receive_date>?");
	$statement->execute(array('1',$timestamp));
	$result = $statement->fetchAll(PDO::FETCH_ASSOC);    
	$tableData ="";                        
    foreach ($result as $row) {
    	$tableData .= '
                <tr>
                  <td>'.key($result).'</td>
                  <td>'.$row['product_china_code'].'</td>
                  <td>'.$row['product_site_track'].'</td>
                  <td>'.date('d/m/Y h:i:s A', $row['product_china_receive_date']).'</td>
                </tr>';
    }
?>

<section class="content">
	<div class="row">

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $total_top_category; ?></h3>
              <p>Top Categories</p>
            </div>
            <div class="icon">
              <i class="fa fa-sitemap"></i>
            </div>
            <a href="#" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $total_mid_category; ?></h3>
              <p>Mid Categories</p>
            </div>
            <div class="icon">
              <i class="fa fa-snowflake-o"></i>
            </div>
            <a href="#" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $total_end_category; ?></h3>
              <p>End Categories</p>
            </div>
            <div class="icon">
              <i class="fa fa-snowflake-o"></i>
            </div>
            <a href="#" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $total_product ?></h3>
              <p>Total Products</p>
            </div>
            <div class="icon">
              <i class="fa fa-cubes"></i>
            </div>
            <a href="#" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>

		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-purple"><i class="fa fa-cubes"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Products</span>
					<span class="info-box-number"><?php echo $total_product; ?></span>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-lime"><i class="fa fa-check"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Completed Orders</span>
					<span class="info-box-number"><?php echo $total_order_completed; ?></span>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-green"><i class="fa fa-check-circle"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Arrived Shipping</span>
					<span class="info-box-number"><?php echo $total_shipping_completed; ?></span>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-red"><i class="fa fa-hourglass-half"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Pending Orders</span>
					<span class="info-box-number"><?php echo $total_order_pending; ?></span>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-blue"><i class="fa fa-envelope"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Messages</span>
					<span class="info-box-number"><?php echo $totalNotes; ?></span>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-black"><i class="fa fa-users"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Users</span>
					<span class="info-box-number"><?php echo $total_users; ?></span>
				</div>
			</div>
		</div>

<section class="content-header">
	<h1  style="margin-top: 50px;">Just Arrived @ China</h1>
</section>

        <div id="dashboardTable" class="col-md-7" style="margin-left: 200px; margin-top: 50px;">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Arrivals</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10%">#</th>
                  <th style="width: 30%">China Tracking</th>
                  <th style="width: 30%">Site Tracking</th>
                  <th style="width: 30%">Date</th>
                </tr>
                <?php echo $tableData; ?>
              </tbody></table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
          </div>
          <!-- /.box -->
        </div>
		
	</div>
</section>

<?php require_once('footer.php'); ?>