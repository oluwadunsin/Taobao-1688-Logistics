<?php
    session_start();
    // Check if the customer is logged in or not
    if(!isset($_SESSION['user'])) {
        header('location: logout.php');
        exit;
    }
		include("inc/config.php");
		include("inc/functions.php");
		include("inc/CSRF_Protect.php");
		
    if(isset($_POST['nid'])) {
        $statement = $pdo->prepare("UPDATE tbl_notes SET status=? WHERE status=? AND order_id=?");
        $statement->execute(array(1, 0, $_POST['nid']));
    }else echo 'nid error';
?>