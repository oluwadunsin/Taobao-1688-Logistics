<?php require_once('header.php'); ?>

<?php

    $error_message = '';
    if(isset($_POST['form4'])) {
        $valid = 1;
        if(!isset($_POST['payment_id'])) {
            $valid = 0;
            $error_message .= 'payment Id error\n';
        }
        if($valid == 1) {
            $statement = $pdo->prepare("UPDATE tbl_payment SET parcel_count=? WHERE payment_id=?");
            $statement->execute(array($_POST['parcel_count'],$_POST['payment_id']));
        }

    }
    
    if(isset($_POST['form3'])) {
        $valid = 1;
        if(!isset($_POST['order_id'])) {
            $valid = 0;
            $error_message .= 'Id error\n';
        }
        if($valid == 1) {
            $statement = $pdo->prepare("INSERT INTO tbl_notes (order_id,message,sender,time,status,status2) VALUES (?,?,?,?,?,?)");
            $statement->execute(array($_POST['order_id'],$_POST['order_notes'],1,time(),1,0));
        }

    }
    
    if(isset($_POST['form2'])) {
        $valid = 1;
        if(empty($_POST['china_code'])) {
            $valid = 0;
            $error_message .= 'China Track Code can not be empty\n';
        }
        if($valid == 1) {
            $statement = $pdo->prepare("UPDATE tbl_order SET product_china_code=? WHERE id=?");
            $statement->execute(array($_POST['china_code'],$_POST['order_id']));

            //Check if product has no china code
            if($_POST['china_code'] === 1){
                $statement = $pdo->prepare("UPDATE tbl_order SET product_china_status=?, product_china_receive_date=? WHERE id=?");
                $statement->execute(array(1, time(), $_POST['order_id']));

            }
            
            //Get site generated tracking number
            $statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                           
            foreach ($result as $row) {
                $site_prefix = $row['site_prefix'];
            }

            $statement = $pdo->prepare("SELECT * FROM tbl_order WHERE id=?");
            $statement->execute(array($_POST['order_id']));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                              
            foreach ($result as $row) {
                $site_track_num = $row['product_site_track'];
                //get product link
                $prod_link = $row['product_link'];
                $payment_id = $row['payment_id'];
                if($site_track_num == ""){
                    $generated_track = $site_prefix.$payment_id.$row['id'];
                    $statement = $pdo->prepare("UPDATE tbl_order SET product_site_track=? WHERE id=?");
                    $statement->execute(array($generated_track,$_POST['order_id']));
                }
            }
            // update all other orders with same product link.

            $statement = $pdo->prepare("SELECT * FROM tbl_order WHERE product_link=? AND payment_id=?");
            $statement->execute(array($prod_link,$payment_id));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                              
            foreach ($result as $row) {
                $site_track_num = $row['product_site_track'];
                //get product link
                $prod_link = $row['product_link'];
                $payment_id = $row['payment_id'];
                $oid = $row['id'];
                if($site_track_num == ""){
                    $generated_track = $site_prefix.$payment_id.$oid;
                    $statement = $pdo->prepare("UPDATE tbl_order SET product_china_code=?, product_site_track=? WHERE id=?");
                    $statement->execute(array($_POST['china_code'],$generated_track,$oid));
                }
            }


        }

    }

    if(isset($_POST['form1'])) {
        $valid = 1;
        if(empty($_POST['subject_text'])) {
            $valid = 0;
            $error_message .= 'Subject can not be empty\n';
        }
        if(empty($_POST['message_text'])) {
            $valid = 0;
            $error_message .= 'Subject can not be empty\n';
        }
        if($valid == 1) {

            $subject_text = strip_tags($_POST['subject_text']);
            $message_text = strip_tags($_POST['message_text']);

            // Getting Customer Email Address
            $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id=?");
            $statement->execute(array($_POST['cust_id']));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
            foreach ($result as $row) {
                $cust_email = $row['cust_email'];
                $cust_name = $row['cust_name'];
            }
            

            $order_detail = '';
            $statement = $pdo->prepare("SELECT * FROM tbl_payment WHERE payment_id=?");
            $statement->execute(array($_POST['payment_id']));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                           
            foreach ($result as $row) {
            	
            	if($row['payment_method'] == 'PayPal'):
            		$payment_details = 'Transaction Id: '.$row['txnid'].'<br>';
            	elseif($row['payment_method'] == 'Stripe'):
    				$payment_details = '
                    Transaction Id: '.$row['txnid'].'<br>
                    Card number: '.$row['card_number'].'<br>
                    Card CVV: '.$row['card_cvv'].'<br>
                    Card Month: '.$row['card_month'].'<br>
                    Card Year: '.$row['card_year'].'<br>';
                elseif($row['payment_method'] == 'Paystack'):
                    $payment_details = '
                    Payment Id:'.$row['payment_id'].'<br>
                    Date:'.$row['payment_date'].'<br>
                    Transaction Id:'.$row['txnid'].'<br>';
            	elseif($row['payment_method'] == 'Bank Deposit'):
    				$payment_details = 'Transaction Details: <br>'.$row['bank_transaction_info'];
            	endif;

                $order_detail .= '
                Customer Name: '.$row['customer_name'].'<br>
                Customer Email: '.$row['customer_email'].'<br>
                Payment Method: '.$row['payment_method'].'<br>
                Payment Date: '.$row['payment_date'].'<br>
                Payment Details: <br>'.$payment_details.'<br>
                Paid Amount: '.$row['paid_amount'].'<br>
                Payment Status: '.$row['payment_status'].'<br>
                Payment Id: '.$row['payment_id'].'<br>';
            }

            $i=0;
            $statement = $pdo->prepare("SELECT * FROM tbl_order WHERE payment_id=?");
            $statement->execute(array($_POST['payment_id']));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
            foreach ($result as $row) {
                $i++;
                $order_detail .= '
                <br><b><u>Product Item '.$i.'</u></b><br>
                Product Name: '.$row['product_name'].'<br>
                Size: '.$row['size'].'<br>
                Color: '.$row['color'].'<br>
                Custom: '.$row['custom'].'<br>
                Comment: '.$row['product_comment'].'<br>
                Quantity: '.$row['quantity'].'<br>
                Unit Price: '.$row['unit_price'].'<br>';
            }

            $statement = $pdo->prepare("INSERT INTO tbl_customer_message (subject,message,order_detail,cust_id) VALUES (?,?,?,?)");
            $statement->execute(array($subject_text,$message_text,$order_detail,$_POST['cust_id']));

            // sending email
            $to_customer = $cust_email;
            $message = '<html><body>
                        <h3>Message: </h3>
                        '.$message_text.'
                        <h3>Order Details: </h3>
                        '.$order_detail.'
                        </body></html>';
            

            try {
                
                $mail->setFrom($admin_email, 'Admin');
                $mail->addAddress($to_customer, $cust_name);
                $mail->addReplyTo($admin_email, 'Admin');
                
                $mail->isHTML(true);
                $mail->Subject = $subject_text;

                $mail->Body = $message;
                $mail->send();

                $statement = $pdo->prepare("INSERT INTO tbl_user_mail (subject,message,time_sent,sender,receiver,status) VALUES (?,?,?,?,?,?)");
                $statement->execute(array($subject_text,$message_text,time(),1,$_POST['cust_id'],1));

                $statement = $pdo->prepare("INSERT INTO tbl_customer_mail (subject,message,time_sent,sender,receiver,status) VALUES (?,?,?,?,?,?)");
                $statement->execute(array($subject_text,$message_text,time(),1,$_POST['cust_id'],0));

                $success_message = 'Your email to customer is sent successfully.';   
            } catch (Exception $e) {
                echo 'Message could not be sent.';
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            }
        }
    }
?>
<?php
    if($error_message != '') {
        echo "<script>alert('".$error_message."')</script>";
    }
    if($success_message != '') {
        echo "<script>alert('".$success_message."')</script>";
    }
?>

<section class="content-header">
	<div class="content-header-left">
		<h1>View Orders</h1>
	</div>
</section>


<section class="content">

  <div class="row">
    <div class="col-md-12">


      <div class="box box-info">
        
        <div class="box-body table-responsive">
          <table id="example1" class="table table-bordered table-striped">
			<thead>
			    <tr class="custTableHead">
			        <th>SL</th>
                    <th>Date</th>
                    <th>Customer Details</th>
			        <th>Product Details</th>
                    <th>Payment Information </th>
                    <th>Paid Amount</th>
                    <th>Payment Status</th>
			        <th>Action</th>
			   </tr>
			</thead>
            <tbody>
            	<?php
                	$i=0;
                	if(isset($_GET['q']) && ($_GET['q'] == 'pending' || $_GET['q'] == 'completed')){
                	    $statement = $pdo->prepare("SELECT * FROM tbl_payment WHERE payment_status=? ORDER by id DESC");
                	    $statement->execute(array(ucfirst($_GET['q'])));
                	}/**else if(isset($_GET['q']) && ($_GET['q'] == 'warehouse')){
                	   //$statement = $pdo->prepare("SELECT * FROM tbl_order LEFT JOIN tbl_payment ON tbl_payment.payment_id = tbl_order.payment_id WHERE tbl_order.product_china_status=? ORDER by tbl_payment.id DESC");
                	    //$statement = $pdo->prepare("SELECT b.product_china_status, b.payment_id, a.* FROM tbl_order b, tbl_payment a WHERE b.payment_id = a.payment_id AND b.product_china_status=? ORDER by a.id DESC");
                	    $statement->execute(array(1));
                	}**/
                	else{
                	    $statement = $pdo->prepare("SELECT * FROM tbl_payment ORDER by id DESC");
                	    $statement->execute();
                	}
                	$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
                	foreach ($result as $row) { 
                                if(isset($_GET['q']) && ($_GET['q'] == 'warehouse')){
                                    $statement2 = $pdo->prepare("SELECT * FROM tbl_order WHERE payment_id=? AND product_china_status=?");
                                    $statement2->execute(array($row['payment_id'],1));
                                    $result2 = $statement2->fetchAll(PDO::FETCH_ASSOC);
                                    $result2_count = $statement2->rowCount();
                                    if($result2_count < 1)continue;
                                    
                                }
                		$i++;
                ?>
					<tr class="<?php if($row['payment_status']=='Pending'){echo 'bg-r';}else{echo 'bg-g';} ?>">
	                    <td><?php echo $i; ?></td>
                        <td>
                            <?php 
                                if(isset($_GET['q']) && ($_GET['q'] == 'warehouse')){
                                    $statement4 = $pdo->prepare("SELECT * FROM tbl_order WHERE payment_id=? AND product_china_status=?");
                                    $statement4->execute(array($row['payment_id'],1));
                                    
                                }else{
                                    $statement4 = $pdo->prepare("SELECT * FROM tbl_order WHERE payment_id=?");
                                    $statement4->execute(array($row['payment_id']));
                                }
                                $result4 = $statement4->fetchAll(PDO::FETCH_ASSOC);
                                $result4_count = $statement4->rowCount();
                                $count = 0;
                                foreach ($result4 as $row4) {
                                    if($count == 0){
                                        echo date('d/m/Y', $row4['order_date']);
                                        break;
                                    }
                                    $count++;
                                }
                            ?>
                        </td>
	                    <td>
                            <b>Id:</b> <?php echo $row['customer_id']; ?><br>
                            <b>Name:</b><br> <?php echo $row['customer_name']; ?><br>
                            <b>Email:</b><br> <?php echo $row['customer_email']; ?><br><br>
                            <a href="#" data-toggle="modal" data-target="#model-<?php echo $i; ?>"class="btn btn-warning btn-xs" style="width:100%;margin-bottom:4px;">Send Message</a>
                            <div id="model-<?php echo $i; ?>" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<div class="modal-content" style="border: 2px solid #352121ba; margin-top: 100px; border-radius: 15px;">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal" style="opacity: 1; color: #a71e1e; font-weight: 500; border-radius: 50%; border: 1px solid black; padding: 2px;">&times;</button>
											<h4 class="modal-title" style="color:#0e3c90; text-align: center;">Send Message</h4>
										</div>
										<div class="modal-body custModalBody" style="font-size: 14px; height: 330px;">
											<form action="" method="post">
                                                <input type="hidden" name="cust_id" value="<?php echo $row['customer_id']; ?>">
                                                <input type="hidden" name="payment_id" value="<?php echo $row['payment_id']; ?>">
                                                    <div class="form-group custModal">
                                                        <div class="col-sm-6" style="padding-top:6px;">
                                                                <label for="" class="col-sm-2 control-label"><strong>Subject</strong></label>
                                                                <input type="text" name="subject_text" class="form-control custInput2">
                                                        </div>
                                                    </div>
                                                    <div class="form-group custModal">
                                                        <div class="col-sm-6" style="padding-top:6px;">
                                                                <label for="" class="col-sm-2 control-label"><strong>Message</strong></label>
                                                                <textarea name="message_text" class="form-control custInput2" cols="30" rows="10"></textarea>
    
                                                        </div>
                                                    </div>
                                                    <div class="form-group custModal">
                                                        <div class="col-sm-6" style="padding-top:6px;">
                                                                <button type="submit" class="btn btn-info copy_btn custBtn" value="Send Message" name="form1">Send Message</button>
                                                        </div>
                                                    </div>
											</form>
										</div>
									</div>
								</div>
							</div>
                            <a href="#" data-toggle="modal" data-target="#modelz-<?php echo $i; ?>"class="btn btn-primary btn-xs" style="width:100%;margin-bottom:4px;">Parcel</a>
                            <div id="modelz-<?php echo $i; ?>" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<div class="modal-content" style="border: 2px solid #352121ba; margin-top: 100px; border-radius: 15px;">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal" style="opacity: 1; color: #a71e1e; font-weight: 500; border-radius: 50%; border: 1px solid black; padding: 2px;">&times;</button>
											<h4 class="modal-title" style="color:#0e3c90; text-align: center;">Set Parcel</h4>
										</div>
										<div class="modal-body custModalBody" style="font-size: 14px; height: 150px;">
											<form action="" method="post">
                                                    <input type="hidden" name="payment_id" value="<?php echo $row['payment_id']; ?>">
                                                    <div class="form-group custModal">
                                                        <div class="col-sm-6" style="padding-top:6px;">
                                                                <label for="" class="col-sm-2 control-label"><strong>Parcel Total</strong></label>
                                                                <input type="text" value="<?php echo $row['parcel_count']; ?>" name="parcel_count" class="form-control custInput2">
                                                        </div>
                                                    </div>
                                                    <div class="form-group custModal">
                                                        <div class="col-sm-6" style="padding-top:6px;">
                                                                <button type="submit" class="btn btn-info copy_btn custBtn" value="Send Message" name="form4">Set Parcel</button>
                                                        </div>
                                                    </div>
											</form>
										</div>
									</div>
								</div>
							</div>
							<a href="view-order.php?id=<?php echo $row['payment_id']; ?>" target="_blank" class="btn btn-default btn-xs" style="width:100%;margin-bottom:4px;">View</a>
                        </td>
                        <td>
                           <?php
                               $count = 1;
                               foreach ($result4 as $row1) {
                                    echo '<b>Product Name:</b> '.$row1['product_name'];
                                    echo '<br>(<b>Size:</b> '.$row1['size'];
                                    echo ',<br><b>(Color:</b> '.$row1['color'].')';
                                    echo ',<br><b>(Custom:</b> '.$row1['custom'].')';
                                    echo '<br>(<b>Quantity:</b> '.$row1['quantity'];
                                    echo ',<br><b>Unit Price:</b> '.$row1['unit_price'].')';
                                    echo '<br><br>';
                                    echo '<hr style=" border: 1px solid #D3D3D3; border-radius: 5px;">';
                                    echo '<b>Info:</b> '.$row1['product_comment'];
                                    echo '<br><br>';
                                    echo '<hr style=" border: 1px solid #12f3f3; border-radius: 5px;">';
                                        $product_link = $row1['product_link'];
                                        if($product_link !== ""){
                                            if($result4_count >= 1){
                                                echo '<a id="'.$i.$row1['id'].'" data-clipboard-text="'.$product_link.'" class="btn btn-info btn-xs copy_btn" style="width:100%;">Copy Link</a>';
                                            }
                                        }
                                    echo '<br><br>';
                                    echo '<hr style=" border: 1px solid #FFFF00; border-radius: 5px;">';
                                    echo '<b>China:</b><br>';
                                            
                                            
                                                if($row1['product_china_status'] == "" || $row1['product_china_status'] == 0){
                                                    echo '<button type="button" style="width:100%;" class="btn btn-'.(($row1['product_china_code'] == "") ? "primary" : "success").' btn-xs" data-toggle="modal" data-target="#myChinaModal'.$i.$row1['id'].'">'.(($row1['product_china_code'] == "") ? "Not Set" : $row1['product_china_code']).'</button>
                                                    <div id="myChinaModal'.$i.$row1['id'].'" class="modal fade" role="dialog">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content" style="border: 2px solid #352121ba; margin-top: 100px; border-radius: 15px;">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close" data-dismiss="modal" style="opacity: 1; color: #a71e1e; font-weight: 500; border-radius: 50%; border: 1px solid black; padding: 2px;">&times;</button>
                                                                    <h4 class="modal-title" style="color:#0e3c90; text-align: center;">Set China Tracking Code</h4><br>
                                                                    <div style="text-align:center;"><i>Input "1" if product has no China Tracking Code</i></div>
                                                                </div>
                                                                <div class="modal-body" style="font-size: 14px; height:150px;">
                                                                    <form action="" method="post">
                                                                        <input type="hidden" name="order_id" value="'.$row1['id'].'">
                                                                        <div class="form-group custModal">
                                                                            <div class="col-sm-6" style="padding-top:6px;">
                                                                                    <label for="" class="col-sm-2 control-label"><strong>Track Code</strong></label>
                                                                                    <input type="text" name="china_code" value="'.$row1['product_china_code'].'" class="form-control custInput2">
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group custModal">
                                                                            <div class="col-sm-6" style="padding-top:6px;">
                                                                                    <button type="submit" class="btn btn-info copy_btn custBtn" value="Update" name="form2">Update</button>
                                                                            </div>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>';
                                                }else{
                                                    echo '<b>Status:</b> received';
                                                    echo '<br><b>date:</b> '.date('d/m/Y', $row1['product_china_receive_date']);
                                                }
                                                
                                                if($row1['product_china_code'] != ""){
                                                    $statementg = $pdo->prepare("SELECT * FROM tbl_notes WHERE order_id=? ORDER BY time ASC");
                                                    $statementg->execute(array($row1['id']));
                                                    $res=  $statementg->fetchAll(PDO::FETCH_ASSOC);     
                                                    $chatz = null;
                                                    foreach ($res as $row) {
                                                        if($row['sender']==1){
                                                            $chatz .= '<div class="containerz darkerz"><img src="https://www.w3schools.com/w3images/bandmember.jpg" alt="Avatar" class="rightz" style="width:100%;"><p>'.$row['message'].'</p><span class="time-leftz">'.date('j/n/y g:i:s a',$row['time']).'</span></div>';
                                                        }else{
                                                            $chatz .= '<div class="containerz"><img src="https://www.w3schools.com/w3images/avatar_g2.jpg" alt="Avatar" style="width:100%;"><p>'.$row['message'].'</p><span class="time-rightz">'.date('j/n/y g:i:s a',$row['time']).'</span></div>';
                                                        }
                                                    }
                                                        echo '<br><button type="button" style="width:100%;" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#myNotesModal'.$i.$row1['id'].'">View Notes</button>
                                                            <div id="myNotesModal'.$i.$row1['id'].'" class="modal fade" role="dialog">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content" style="border: 2px solid #352121ba; margin-top: 100px; border-radius: 15px;">
                                                                        <div class="modal-header">
                                                                            <button type="button" class="close" data-dismiss="modal" style="opacity: 1; color: #a71e1e; font-weight: 500; border-radius: 50%; border: 1px solid black; padding: 2px;">&times;</button>
                                                                            <h4 class="modal-title" style="color:#0e3c90; text-align: center;">Order Notes</h4><br>
                                                                            <div style="text-align:center;"><i>Warehouse Manager Notes</i></div>
                                                                        </div>
                                                                            <div class="modal-body" style="font-size: 14px; height:fit-content; overflow:auto;">
                                                                                <form action="" method="post">
                                                                                    <input type="hidden" name="order_id" value="'.$row1['id'].'">
                                                                                    <div class="form-group custModal">
                                                                                        <div class="col-sm-6" style="padding-top:6px;">
                                                                                                <input type="hidden" name="china_code" value="'.$row1['product_china_code'].'">
                                                                                                '.$chatz.'
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="form-group custModal">
                                                                                        <div class="col-sm-6" style="padding-top:6px; display:flex;">
                                                                                                <input type="text" name="order_notes" class="form-control custInput2">
                                                                                                <button type="submit" class="btn btn-info copy_btn custBtn" value="Update" name="form3" style="margin-top:0px">Update</button>
                                                                                        </div>
                                                                                    </div>
                                                                                </form>
                                                                            </div>
                                                                    </div>
                                                                </div>
                                                            </div>';
                                                }
                                    
                                    
                                    echo '<br><br>';
                                    echo '<hr style=" border: 1px solid #32CD32; border-radius: 5px;">';
                                                   /**if($row1['product_china_code'] != ""){
                                                        $status = json_decode($row1['product_shipping_status'],true);
                                                        echo '<a href="#" class="btn btn-success btn-xs" style="width:100%;margin-bottom:4px;" data-toggle="modal" data-target="#myShippingModal'.$i.$row1['id'].'">Edit</a>
                                                            <div id="myShippingModal'.$i.$row1['id'].'" class="modal fade" role="dialog">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content" style="border: 2px solid #352121ba; margin-top: 100px; border-radius: 15px;">
                                                                        <div class="modal-header">
                                                                            <button type="button" class="close" data-dismiss="modal" style="opacity: 1; color: #a71e1e; font-weight: 500; border-radius: 50%; border: 1px solid black; padding: 2px;">&times;</button>
                                                                            <h4 class="modal-title" style="color:#0e3c90; text-align: center;">Update Shipping Information</h4><br>
                                                                            <div style="text-align:center;"><i style="text-align:centered;">Product Tracking Code is <b>'.$row1['product_site_track'].'</b></i></div>
                                                                        </div>
                                                                        <div class="modal-body custModalBody" style="font-size: 14px">
                                                                            <form action="shipping-change-status.php" method="post">
                                                                                <input type="hidden" name="order_id" value="'.$row1['id'].'">
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_0" value="'.$status[0].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_1" value="'.$status[1].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_2" value="'.$status[2].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_3" value="'.$status[3].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_4" value="'.$status[4].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_5" value="'.$status[5].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_6" value="'.$status[6].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_7" value="'.$status[7].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_8" value="'.$status[8].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_9" value="'.$status[9].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <button type="submit" class="btn btn-info copy_btn custBtn" value="Update" name="form3">Update</button>
                                                                                    </div>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>';
                                                    }**/
                                    echo '<br><br>';
                                    if($result4_count > 1 && $count !== $result4_count){
                                         echo '<hr style=" border: 3px solid #FF4500;">';
                                         echo '<div style=" margin: auto; text-align: center; font-size: 15px">'.($count+1).'</div><br>';
                                         echo '<hr style=" border: 3px solid #FF4500; margin-top:0px;">';
                                         $count++;
                                    }
                               }
                           ?>
                        </td>
                        <td>
                        	<?php if($row['payment_method'] == 'PayPal'): ?>
                        		<b>Payment Method:</b> <?php echo '<span style="color:red;"><b>'.$row['payment_method'].'</b></span>'; ?><br>
                        		<b>Payment Id:</b> <?php echo $row['payment_id']; ?><br>
                        		<b>Date:</b> <?php echo $row['payment_date']; ?><br>
                        		<b>Transaction Id:</b> <?php echo $row['txnid']; ?><br>
                        	<?php elseif($row['payment_method'] == 'Stripe'): ?>
                        		<b>Payment Method:</b> <?php echo '<span style="color:red;"><b>'.$row['payment_method'].'</b></span>'; ?><br>
                        		<b>Payment Id:</b> <?php echo $row['payment_id']; ?><br>
								<b>Date:</b> <?php echo $row['payment_date']; ?><br>
                        		<b>Transaction Id:</b> <?php echo $row['txnid']; ?><br>
                        		<b>Card Number:</b> <?php echo $row['card_number']; ?><br>
                        		<b>Card CVV:</b> <?php echo $row['card_cvv']; ?><br>
                        		<b>Expire Month:</b> <?php echo $row['card_month']; ?><br>
                        		<b>Expire Year:</b> <?php echo $row['card_year']; ?><br>
                            <?php elseif($row['payment_method'] == 'Paystack'): ?>
                                <b>Payment Method:</b> <?php echo '<span style="color:red;"><b>'.$row['payment_method'].'</b></span>'; ?><br>
                                <b>Payment Id:</b> <?php echo $row['payment_id']; ?><br>
                                <b>Date:</b> <?php echo $row['payment_date']; ?><br>
                                <b>Transaction Id:</b> <?php echo $row['txnid']; ?><br>
                        	<?php elseif($row['payment_method'] == 'Bank Deposit'): ?>
                        		<b>Payment Method:</b> <?php echo '<span style="color:red;"><b>'.$row['payment_method'].'</b></span>'; ?><br>
                        		<b>Payment Id:</b> <?php echo $row['payment_id']; ?><br>
								<b>Date:</b> <?php echo $row['payment_date']; ?><br>
                        		<b>Transaction Information:</b> <br><?php echo $row['bank_transaction_info']; ?><br>
                        	<?php endif; ?>
                        </td>
                        <td><?php echo $row['paid_amount']; ?></td>
                        <td>
                            <?php echo $row['payment_status']; ?>
                            <br><br>
                            <?php
                                if($row['payment_status']=='Pending'){
                                    ?>
                                    <a href="order-change-status.php?id=<?php echo $row['id']; ?>&task=Completed" class="btn btn-primary btn-xs" style="width:100%;margin-bottom:4px;">Make Completed</a>
                                    <?php
                                }if($row['payment_status']=='Completed'){
                                    echo '<a href="view-invoice.php?id='.$row['id'].'" class="btn btn-success btn-xs" style="width:100%;margin-bottom:4px;">View Invoice</a>';
                                }
                            ?>
                        </td>
	                    <td style="vertical-align: middle;">
                            <a href="#" class="btn btn-danger btn-xs" data-href="order-delete.php?id=<?php echo $row['id']; ?>" data-toggle="modal" data-target="#confirm-delete" style="width:100%;">Delete</a>
	                    </td>
	                </tr>
            	<?php
            	    }
            	?>
            </tbody>
          </table>
        </div>
      </div>
  

</section>


<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
            </div>
            <div class="modal-body">
                Are you sure want to delete this item?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger btn-ok">Delete</a>
            </div>
        </div>
    </div>
</div>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
    
    function viewMark(did){
        
		let dataString = 'nid=' + did;

        // AJAX code to submit form.
        $.ajax({
            type: "POST",
            url: "note-update",
            data: dataString,
            cache: false,
            success: function(data) {
                //alert('messsage read');
            },
            error: function (errorThrown) { /**alert('messsage error '+errorThrown);**/ }
        });
        
    }
</script>
<?php require_once('footer.php'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/notify.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>
<script>
    var clipboard = new ClipboardJS('.copy_btn');
    clipboard.on('success', function(e) {
        let trigg = e.trigger.getAttribute('id');
        $('#'+trigg).notify("Copied", 'success');
        e.clearSelection();
    });

    clipboard.on('error', function(e) {
        let trigg = e.trigger.getAttribute('id');
        $('#'+trigg).notify("Not Copied", 'error');
        e.clearSelection();
    });
</script>