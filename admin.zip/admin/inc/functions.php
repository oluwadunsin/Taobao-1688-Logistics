<?php
function get_ext($pdo,$fname)
{

	$up_filename=$_FILES[$fname]["name"];
	$file_basename = substr($up_filename, 0, strripos($up_filename, '.')); // strip extention
	$file_ext = substr($up_filename, strripos($up_filename, '.')); // strip name
	return $file_ext;
}

function ext_check($pdo,$allowed_ext,$my_ext) 
{

	$arr1 = array();
	$arr1 = explode("|",$allowed_ext);	
	$count_arr1 = count(explode("|",$allowed_ext));	

	for($i=0;$i<$count_arr1;$i++)
	{
		$arr1[$i] = '.'.$arr1[$i];
	}
	

	$str = '';
	$stat = 0;
	for($i=0;$i<$count_arr1;$i++)
	{
		if($my_ext == $arr1[$i])
		{
			$stat = 1;
			break;
		}
	}

	if($stat == 1)
		return true; // file extension match
	else
		return false; // file extension not match
}


function get_ai_id($pdo,$tbl_name) 
{
	$statement = $pdo->prepare("SHOW TABLE STATUS LIKE '$tbl_name'");
	$statement->execute();
	$result = $statement->fetchAll(PDO::FETCH_ASSOC);
	foreach($result as $row)
	{
		$next_id = $row['Auto_increment'];
	}
	return $next_id;
}

function store_cart($pdo){
    if(isset($_SESSION['cart_p_id']) && isset($_SESSION['cart_size_id']) && isset($_SESSION['cart_size_name']) && isset($_SESSION['cart_color_id']) && isset($_SESSION['cart_color_name']) &&
     isset($_SESSION['cart_cust_val']) && isset($_SESSION['cart_p_type']) && isset($_SESSION['cart_p_qty']) && isset($_SESSION['cart_p_current_price']) && isset($_SESSION['cart_p_name']) &&
      isset($_SESSION['cart_p_featured_photo'])){
          
        $cart_p_id = serialize($_SESSION['cart_p_id']);
        $cart_size_id = serialize($_SESSION['cart_size_id']);
        $cart_size_name = serialize($_SESSION['cart_size_name']);
        $cart_color_id = serialize($_SESSION['cart_color_id']);
        $cart_color_name = serialize($_SESSION['cart_color_name']);
        $cart_cust_val = serialize($_SESSION['cart_cust_val']);
        $cart_p_type = serialize($_SESSION['cart_p_type']);
        $cart_p_qty = serialize($_SESSION['cart_p_qty']);
        $cart_p_current_price = serialize($_SESSION['cart_p_current_price']);
        $cart_p_name = serialize($_SESSION['cart_p_name']);
        $cart_p_featured_photo = serialize($_SESSION['cart_p_featured_photo']);
        
        
        $statement = $pdo->prepare("UPDATE tbl_cart SET p_id=?, size_id=?, size_name=?, color_id=?, color_name=?, cust_val=?, p_type=?, p_qty=?, p_current_price=?, p_name=?, p_featured_photo=?  WHERE cust_id=?");
        $statement->execute(array($cart_p_id,$cart_size_id,$cart_size_name,$cart_color_id,$cart_color_name,$cart_cust_val,$cart_p_type,$cart_p_qty,$cart_p_current_price,$cart_p_name,$cart_p_featured_photo,$_SESSION['customer']['cust_id']));
    }else{
        $emptyArray = array();
        $cart_p_id = serialize($emptyArray);
        $cart_size_id = serialize($emptyArray);
        $cart_size_name = serialize($emptyArray);
        $cart_color_id = serialize($emptyArray);
        $cart_color_name =  serialize($emptyArray);
        $cart_cust_val = serialize($emptyArray);
        $cart_p_type = serialize($emptyArray);
        $cart_p_qty = serialize($emptyArray);
        $cart_p_current_price = serialize($emptyArray);
        $cart_p_name = serialize($emptyArray);
        $cart_p_featured_photo = serialize($emptyArray);
        
        
        $statement = $pdo->prepare("UPDATE tbl_cart SET p_id=?, size_id=?, size_name=?, color_id=?, color_name=?, cust_val=?, p_type=?, p_qty=?, p_current_price=?, p_name=?, p_featured_photo=?  WHERE cust_id=?");
        $statement->execute(array($cart_p_id,$cart_size_id,$cart_size_name,$cart_color_id,$cart_color_name,$cart_cust_val,$cart_p_type,$cart_p_qty,$cart_p_current_price,$cart_p_name,$cart_p_featured_photo,$_SESSION['customer']['cust_id']));
        
    }
}

function get_cart($pdo){
    
	$statement = $pdo->prepare("SELECT * FROM tbl_cart WHERE cust_id=?");
	$statement->execute(array($_SESSION['customer']['cust_id']));
	$result = $statement->fetchAll(PDO::FETCH_ASSOC);
	foreach ($result as $row){
	    if(!empty(unserialize($row['p_qty'])) && !empty(unserialize($row['p_id']))){
    	    $_SESSION['cart_p_id'] = unserialize($row['p_id']);
            $_SESSION['cart_size_id'] = unserialize($row['size_id']);
            $_SESSION['cart_size_name'] = unserialize($row['size_name']);
            $_SESSION['cart_color_id'] = unserialize($row['color_id']);
            $_SESSION['cart_color_name'] = unserialize($row['color_name']);
            $_SESSION['cart_cust_val'] = unserialize($row['cust_val']);
            $_SESSION['cart_p_type'] = unserialize($row['p_type']);
            $_SESSION['cart_p_qty'] = unserialize($row['p_qty']);
            $_SESSION['cart_p_current_price'] = unserialize($row['p_current_price']);
            $_SESSION['cart_p_name'] = unserialize($row['p_name']);
            $_SESSION['cart_p_featured_photo'] = unserialize($row['p_featured_photo']);
	    }
	}
    
}