<?php require_once('header.php'); ?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Sent</h1>
	</div>
</section>
 <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3">
          <a href="compose-message.php" class="btn btn-primary btn-block margin-bottom">Compose</a>

          <div class="box box-solid">
	            <div class="box-header with-border">
	              <h3 class="box-title">Folders</h3>

	              <div class="box-tools">
	                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
	                </button>
	              </div>
	            </div>
	            <div class="box-body no-padding">
	              <ul class="nav nav-pills nav-stacked">
	                <li>
	                	<a href="general-message.php">
	                		<i class="fa fa-inbox"></i> Inbox
	                  		<?php if($totalMsg != 0) echo '<span class="label label-primary pull-right">'.$totalMsg.'</span>' ?>
	                  </a>
	                </li>
	                <li class="active"><a href="sent-message.php"><i class="fa fa-envelope-o"></i> Sent</a></li>
	              </ul>
	            </div>
	            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Sent</h3>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-controls">
                <a href="general-message.php" class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></a>
              </div>
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover table-striped">
                  <tbody>
                  	<?php
		            	    $statement = $pdo->prepare("SELECT * FROM tbl_user_mail WHERE sender=1 ORDER by time_sent DESC");
		            	    $statement->execute();
		            	    $result = $statement->fetchAll(PDO::FETCH_ASSOC);							
            	        foreach ($result as $row){	
								          $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id=?");
								          $statement->execute(array($row['receiver']));
						              $result2= $statement->fetchAll(PDO::FETCH_ASSOC);                           
      						        foreach ($result2 as $row2) {
      						            $cust_name = $row2['cust_name'];
      						        }
            	        	echo '<tr>';
            	        	if($row['status'] == 0) echo '<td class="mailbox-star"><a href="view-message.php?id='.$row['id'].'"><i class="fa fa-star text-yellow"></i></a></td>';
            	        	else echo'<td class="mailbox-star"><a href="view-message.php?id='.$row['id'].'"><i class="fa fa-star-o text-yellow"></i></a></td>';
            	        	echo'<td class="mailbox-name"><a href="view-message.php?id='.$row['id'].'">'.$cust_name.'</a></td>';
            	        	if($row['status'] == 0) echo '<td class="mailbox-subject"><b>'.$row['subject'].'</b> - '.substr($row['message'],0,8).'...</td>';
            	        	else echo'<td class="mailbox-subject">'.$row['subject'].'</td>';
            	        	echo '<td class="mailbox-date">'.date('d/m/Y', $row['time_sent']).'</td>';
            	        	echo '<td class="mailbox-attachment"><a href="delete-message.php?id='.$row['id'].'" class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></a></td>';
            	        	echo '</tr>';
            	        }
                  	?>
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer no-padding">
              <div class="mailbox-controls">
                <!-- /.btn-group -->
                <a href="general-message.php" class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></a>
              </div>
            </div>
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

<?php require_once('footer.php'); ?>