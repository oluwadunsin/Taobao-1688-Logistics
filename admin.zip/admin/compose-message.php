<?php require_once('header.php'); ?>

<?php

    if(isset($_REQUEST['id'])) {
        // Check the id is valid or not
        $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id=?");
        $statement->execute(array($_REQUEST['id']));
        $total = $statement->rowCount();
        if( $total == 0 ) {
          header('location: logout.php');
          exit;
        }else{
          $customers="";
          $result= $statement->fetchAll(PDO::FETCH_ASSOC);                           
          foreach ($result as $row) {
              $customers .= "<option value='".$row['cust_id']."'>".$row['cust_name']."  :  ".$row['cust_email']."</option>";
          }

        }
    }else{
        // Getting Customer Email Address
        $customers="";
        $statement = $pdo->prepare("SELECT * FROM tbl_customer");
        $statement->execute();
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
        foreach ($result as $row) {
            $customers .= "<option value='".$row['cust_id']."'>".$row['cust_name']."  :  ".$row['cust_email']."</option>";
        }
    }

    if(isset($_POST['form1'])) {
        $valid = 1;
        if(empty($_POST['subject_text'])) {
            $valid = 0;
            $error_message .= 'Subject can not be empty\n';
        }
        if(empty($_POST['message_text'])) {
            $valid = 0;
            $error_message .= 'Subject can not be empty\n';
        }
        if(empty($_POST['recipient'])) {
            $valid = 0;
            $error_message .= 'Select a recipient\n';
        }
        if($valid == 1) {

            $subject_text = strip_tags($_POST['subject_text']);
            $message_text = strip_tags($_POST['message_text']);

            // Getting Customer Email Address
            $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id=?");
            $statement->execute(array($_POST['recipient']));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                            
            foreach ($result as $row) {
                $cust_email = $row['cust_email'];
                $cust_name = $row['cust_name'];
            }

            // sending email
            $message = '<html><body>
                        <h3>Message: </h3>
                        '.$message_text.'
                        </body></html>';
            

            try {
                
                $mail->setFrom($admin_email, 'Admin');
                $mail->addAddress($to_customer, $cust_name);
                $mail->addReplyTo($admin_email, 'Admin');
                
                $mail->isHTML(true);
                $mail->Subject = $subject;

                $mail->Body = $message;
                $mail->send();

                $statement = $pdo->prepare("INSERT INTO tbl_user_mail (subject,message,time_sent,sender,receiver,status) VALUES (?,?,?,?,?,?)");
                $statement->execute(array($subject_text,$message_text,time(),1,$_POST['recipient'],1));

                $statement = $pdo->prepare("INSERT INTO tbl_customer_mail (subject,message,time_sent,sender,receiver,status) VALUES (?,?,?,?,?,?)");
                $statement->execute(array($subject_text,$message_text,time(),1,$_POST['recipient'],0));

                $success_message = 'Your email to customer is sent successfully.';   
            } catch (Exception $e) {
                echo 'Message could not be sent.';
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            }
            
            

        }
    }
?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Compose Mail
      </h1>
    </section>

     <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3">
          <a href="general-message.php" class="btn btn-primary btn-block margin-bottom">Back to Inbox</a>

          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Folders</h3>

              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
              <div class="box-body no-padding">
                <ul class="nav nav-pills nav-stacked">
                  <li>
                    <a href="general-message.php">
                      <i class="fa fa-inbox"></i> Inbox
                        <?php if($totalMsg != 0) echo '<span class="label label-primary pull-right">'.$totalMsg.'</span>' ?>
                    </a>
                  </li>
                  <li class="active"><a href="sent-message.php"><i class="fa fa-envelope-o"></i> Sent</a></li>
                </ul>
              </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Compose New Message</h3>
            </div>
                  <form action="" method="post">
                      <!-- /.box-header -->
                      <div class="box-body">
                              <div class="form-group">
                                <select class="form-control" name="recipient" placeholder="To:" required>
                                     <option value="">Select Customer</option>
                                      <?php echo $customers; ?>
                                </select>
                              </div>
                              <div class="form-group">
                                <input class="form-control" name="subject_text" placeholder="Subject:" required>
                              </div>
                              <div class="form-group">
                                    <textarea id="editor1" name="message_text" class="form-control" style="height: 300px" required>
                                    </textarea>
                              </div>
                      </div>
                      <!-- /.box-body -->
                      <div class="box-footer">
                        <div class="pull-right">
                          <button type="submit" name= "form1" value="send" class="btn btn-primary"><i class="fa fa-envelope-o"></i> Send</button>
                        </div>
                        <a href="general-messages.php" class="btn btn-default"><i class="fa fa-times"></i> Discard</a>
                      </div>
                 </form>
            <!-- /.box-footer -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

<?php require_once('footer.php'); ?>