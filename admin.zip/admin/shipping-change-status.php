<?php require_once('header.php'); ?>

<?php

	if( !isset($_POST['order_id'])) {
		header('location: logout.php');
		exit;
	} else {
		// Check the id is valid or not
		$statement = $pdo->prepare("SELECT * FROM tbl_order WHERE id=?");
		$statement->execute(array($_POST['order_id']));
        //get site tracking number
        $prod_track = $row['product_china_code'];
		$total = $statement->rowCount();
		if( $total == 0 ) {
			header('location: logout.php');
			exit;
		}
	} 
    if(isset($_POST['form3'])) {
        $status = array($_POST['shippping_status_0'], $_POST['shippping_status_1'], $_POST['shippping_status_2'], $_POST['shippping_status_3'], $_POST['shippping_status_4'], $_POST['shippping_status_5'], $_POST['shippping_status_6'], $_POST['shippping_status_7'], $_POST['shippping_status_8'], $_POST['shippping_status_9']);

            $statement = $pdo->prepare("UPDATE tbl_order SET product_shipping_status=? WHERE id=?");
            $statement->execute(array(json_encode($status),$_POST['order_id']));
            // update all other orders with same site tracking number.
            $statement = $pdo->prepare("UPDATE tbl_order SET product_shipping_status=? WHERE product_china_code=?");
            $statement->execute(array(json_encode($status),$prod_track));
	        header('location: order.php');

    }

?>