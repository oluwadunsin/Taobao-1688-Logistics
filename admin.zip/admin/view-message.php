<?php require_once('header.php'); ?>

<?php
    if(!isset($_REQUEST['id'])) {
      header('location: logout.php');
      exit;
    } else {
        // Check the id is valid or not
        $statement = $pdo->prepare("SELECT * FROM tbl_user_mail WHERE id=?");
        $statement->execute(array($_REQUEST['id']));
        $total = $statement->rowCount();
        if( $total == 0 ) {
          header('location: logout.php');
          exit;
        } else {
          $id = $_REQUEST['id'];
          $result = $statement->fetchAll(PDO::FETCH_ASSOC);             
          foreach ($result as $row) {
            $subject = $row['subject'];
            $message = $row['message'];
            $status = $row['status'];
            $time = date('d/m/Y', $row['time_sent']);
            $receiver = $row['receiver'];
            $sentBy= $row['sender'];
          }
          if($sentBy == 1){
              $sender = 'Admin';
              $sender_id = 1;
              $sender_email = $admin_email;
          }else{
              $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id=?");
              $statement->execute(array($sentBy));
              $result= $statement->fetchAll(PDO::FETCH_ASSOC);                           
              foreach ($result as $row) {
                  $sender = $row['cust_name'];
                  $sender_id = $row['cust_id'];
                  $sender_email = $row['cust_email'];
              }
          }

          // updating the database mail status
          $statement = $pdo->prepare("UPDATE tbl_user_mail SET status=? WHERE id=?");
          $statement->execute(array(1, $id));
        }
    }
?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        View Mail
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3">
          <a href="compose.html" class="btn btn-primary btn-block margin-bottom">Compose</a>

          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Folders</h3>

              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
              <div class="box-body no-padding">
                <ul class="nav nav-pills nav-stacked">
                  <li>
                    <a href="general-message.php">
                      <i class="fa fa-inbox"></i> Inbox
                        <?php if($totalMsg != 0) echo '<span class="label label-primary pull-right">'.$totalMsg.'</span>' ?>
                    </a>
                  </li>
                  <li><a href="sent-message.php"><i class="fa fa-envelope-o"></i> Sent</a></li>
                </ul>
              </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Read Mail</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-read-info">
                <h3><?php echo $subject; ?></h3>
                <h5>From: <?php echo $sender; ?> - <?php echo $sender_email; ?>
                  <span class="mailbox-read-time pull-right"><?php echo $time; ?></span></h5>
              </div>
              <!-- /.mailbox-read-info -->
              <div class="mailbox-controls with-border text-center">
                <div class="btn-group">
                    <a href="delete-message.php?id=<?php echo $id; ?> " data-toggle="tooltip" data-container="body"  title="Delete" class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></a>
                    <a href="compose-message.php?id=<?php echo $sender_id; ?>" data-toggle="tooltip" data-container="body"  title="Reply" class="btn btn-default btn-sm"><i class="fa fa-reply"></i></a>
                </div>
              </div>
              <!-- /.mailbox-controls -->
              <div class="mailbox-read-message">
                <p>Hello,</p>

                <p><?php echo $message ?></p>
              </div>
              <!-- /.mailbox-read-message -->
            </div>
            <!-- /.box-footer -->
            <div class="box-footer">
              <div class="pull-right">
                <button type="button" class="btn btn-default"><i class="fa fa-reply"></i> Reply</button>
              </div>
              <button type="button" class="btn btn-default"><i class="fa fa-trash-o"></i> Delete</button>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

<?php require_once('footer.php'); ?>