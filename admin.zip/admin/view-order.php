<?php 
    require_once('header.php');
    if(!isset($_GET['id'])) {
      header('location: logout.php');
      exit;
    }
?>
<style>

.containerz {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

.darkerz {
  border-color: #ccc;
  background-color: #ddd;
}

.containerz::after {
  content: "";
  clear: both;
  display: table;
}

.containerz img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.containerz img.rightz {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-rightz {
  float: right;
  color: #aaa;
}

.time-leftz {
  float: left;
  color: #999;
}
</style>
<?php

    $error_message = '';
    if(isset($_POST['form3'])) {
        $valid = 1;
        if(!isset($_POST['order_id'])) {
            $valid = 0;
            $error_message .= 'Id error\n';
        }
        if($valid == 1) {
            $statement = $pdo->prepare("INSERT INTO tbl_notes (order_id,message,sender,time,status,status2) VALUES (?,?,?,?,?,?)");
            $statement->execute(array($_POST['order_id'],$_POST['order_notes'],1,time(),1,0));
        }

    }
    
    if(isset($_POST['form2'])) {
        $valid = 1;
        if(empty($_POST['china_code'])) {
            $valid = 0;
            $error_message .= 'China Track Code can not be empty\n';
        }
        if($valid == 1) {
            $statement = $pdo->prepare("UPDATE tbl_order SET product_china_code=? WHERE id=?");
            $statement->execute(array($_POST['china_code'],$_POST['order_id']));

            //Check if product has no china code
            if($_POST['china_code'] === 1){
                $statement = $pdo->prepare("UPDATE tbl_order SET product_china_status=?, product_china_receive_date=? WHERE id=?");
                $statement->execute(array(1, time(), $_POST['order_id']));

            }
            
            //Get site generated tracking number
            $statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                           
            foreach ($result as $row) {
                $site_prefix = $row['site_prefix'];
            }

            $statement = $pdo->prepare("SELECT * FROM tbl_order WHERE id=?");
            $statement->execute(array($_POST['order_id']));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                              
            foreach ($result as $row) {
                $site_track_num = $row['product_site_track'];
                //get product link
                $prod_link = $row['product_link'];
                $payment_id = $row['payment_id'];
                if($site_track_num == ""){
                    $generated_track = $site_prefix.$payment_id.$row['id'];
                    $statement = $pdo->prepare("UPDATE tbl_order SET product_site_track=? WHERE id=?");
                    $statement->execute(array($generated_track,$_POST['order_id']));
                }
            }
            // update all other orders with same product link.

            $statement = $pdo->prepare("SELECT * FROM tbl_order WHERE product_link=? AND payment_id=?");
            $statement->execute(array($prod_link,$payment_id));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);                              
            foreach ($result as $row) {
                $site_track_num = $row['product_site_track'];
                //get product link
                $prod_link = $row['product_link'];
                $payment_id = $row['payment_id'];
                $oid = $row['id'];
                if($site_track_num == ""){
                    $generated_track = $site_prefix.$payment_id.$oid;
                    $statement = $pdo->prepare("UPDATE tbl_order SET product_china_code=?, product_site_track=? WHERE id=?");
                    $statement->execute(array($_POST['china_code'],$generated_track,$oid));
                }
            }


        }

    }
?>
<?php
    if($error_message != '') {
        echo "<script>alert('".$error_message."')</script>";
    }
    if($success_message != '') {
        echo "<script>alert('".$success_message."')</script>";
    }
?>

<section class="content-header">
	<div class="content-header-left">
		<h1>View Orders</h1>
	</div>
</section>


<section class="content">

  <div class="row">
    <div class="col-md-12">


      <div class="box box-info">
        
        <div class="box-body table-responsive">
          <table id="example1" class="table table-bordered table-striped">
			<thead>
			    <tr class="custTableHead">
			        <th>S/N</th>
			        <th>Product Details</th>
			        <th>Info</th>
                    <th>Link</th>
                    <th>China</th>
                    <th>Track </th>
                    <th>Action </th>
			    </tr>
			</thead>
            <tbody>
                <?php 
                    if(!isset($_GET['q'])){
                        $statement1 = $pdo->prepare("SELECT * FROM tbl_order WHERE payment_id=?");
                        $statement1->execute(array($_GET['id']));
                        $result1 = $statement1->fetchAll(PDO::FETCH_ASSOC);
                        $result1_count = $statement1->rowCount();
                    }else if(isset($_GET['q']) && ($_GET['q'] == 'notes')){
                        $statement1 = $pdo->prepare("SELECT order_id FROM tbl_notes WHERE status=? AND sender=?");
                        $statement1->execute(array(0,2));
                        $arrayz =  $statement1->fetchAll(PDO::FETCH_ASSOC); 
                        $array = [];
                        foreach ($arrayz as $raz) {
                            array_push($array,$raz['order_id']);
                        }
                        
                        $result1_count = $result1 = 0;
                        if(count($array)>0){
                            $statement1 = $pdo->prepare("SELECT * FROM tbl_order WHERE id IN (".implode(',',$array).")");
                            $statement1->execute();
                            $result1 = $statement1->fetchAll(PDO::FETCH_ASSOC);
                            $result1_count = $statement1->rowCount();
                        }
                    }
                    $count = 0;
                    echo count($result1);
                    if($result1_count > 0){
                    foreach ($result1 as $row1) {
                        $count++;
                ?>
                        <tr>
    	                    <td><?php echo $count; ?></td>
                            <td>
                               <?php
                                        echo '<b>Product Name:</b> '.$row1['product_name'];
                                        echo '<br>(<b>Size:</b> '.$row1['size'];
                                        echo ',<br><b>(Color:</b> '.$row1['color'].')';
                                        echo ',<br><b>(Custom:</b> '.$row1['custom'].')';
                                        echo '<br>(<b>Quantity:</b> '.$row1['quantity'];
                                        echo ',<br><b>Unit Price:</b> '.$row1['unit_price'].')';
                               ?>
                            </td>
                            <td><?php echo $row1['product_comment']; ?></td>
                            <td>
                                <?php 
                                    $product_link = $row1['product_link'];
                                    if($product_link !== ""){
                                        if($result1_count >= 1){
                                            echo '<a id="'.$row1['id'].'" data-clipboard-text="'.$product_link.'" class="btn btn-info btn-xs copy_btn" style="width:100%;">Copy Link</a>';
                                        }
                                    }
                                ?>
                            </td>
                            <td>
                                <?php
                                    if($row1['product_china_status'] == "" || $row1['product_china_status'] == 0){
                                        echo '<button type="button" style="width:100%;" class="btn btn-'.(($row1['product_china_code'] == "") ? "primary" : "success").' btn-xs" data-toggle="modal" data-target="#myChinaModal'.$row1['id'].'">'.(($row1['product_china_code'] == "") ? "Not Set" : $row1['product_china_code']).'</button>
                                        <div id="myChinaModal'.$row1['id'].'" class="modal fade" role="dialog">
                                            <div class="modal-dialog">
                                                <div class="modal-content" style="border: 2px solid #352121ba; margin-top: 100px; border-radius: 15px;">
                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" style="opacity: 1; color: #a71e1e; font-weight: 500; border-radius: 50%; border: 1px solid black; padding: 2px;">&times;</button>
                                                        <h4 class="modal-title" style="color:#0e3c90; text-align: center;">Set China Tracking Code</h4><br>
                                                        <div style="text-align:center;"><i>Input "1" if product has no China Tracking Code</i></div>
                                                    </div>
                                                    <div class="modal-body" style="font-size: 14px; height:150px;">
                                                        <form action="" method="post">
                                                            <input type="hidden" name="order_id" value="'.$row1['id'].'">
                                                            <div class="form-group custModal">
                                                                <div class="col-sm-6" style="padding-top:6px;">
                                                                        <label for="" class="col-sm-2 control-label"><strong>Track Code</strong></label>
                                                                        <input type="text" name="china_code" value="'.$row1['product_china_code'].'" class="form-control custInput2">
                                                                </div>
                                                            </div>
                                                            <div class="form-group custModal">
                                                                <div class="col-sm-6" style="padding-top:6px;">
                                                                        <button type="submit" class="btn btn-info copy_btn custBtn" value="Update" name="form2">Update</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>';
                                    }else{
                                        echo '<b>Status:</b> received';
                                        echo '<br><b>date:</b> '.date('d/m/Y', $row1['product_china_receive_date']);
                                    }
                                    
                                    if($row1['product_china_code'] != ""){
                                            $statementg = $pdo->prepare("SELECT * FROM tbl_notes WHERE order_id=? ORDER BY time ASC");
                                            $statementg->execute(array($row1['id']));
                                            $res=  $statementg->fetchAll(PDO::FETCH_ASSOC);     
                                            $chatz = null;
                                            foreach ($res as $row) {
                                                if($row['sender']==1){
                                                    $chatz .= '<div class="containerz darkerz"><img src="https://www.w3schools.com/w3images/bandmember.jpg" alt="Avatar" class="rightz" style="width:100%;"><p>'.$row['message'].'</p><span class="time-leftz">'.date('j/n/y g:i:s a',$row['time']).'</span></div>';
                                                }else{
                                                    $chatz .= '<div class="containerz"><img src="https://www.w3schools.com/w3images/avatar_g2.jpg" alt="Avatar" style="width:100%;"><p>'.$row['message'].'</p><span class="time-rightz">'.date('j/n/y g:i:s a',$row['time']).'</span></div>';
                                                }
                                            }
                        
                                            echo '<br><button type="button" style="width:100%;" class="btn btn-warning btn-xs" data-toggle="modal" onclick="viewMark('.$row1['id'].')" data-target="#myNotesModal'.$row1['id'].'">View Notes</button>
                                                <div id="myNotesModal'.$row1['id'].'" class="modal fade" role="dialog">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content" style="border: 2px solid #352121ba; margin-top: 100px; border-radius: 15px;">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" style="opacity: 1; color: #a71e1e; font-weight: 500; border-radius: 50%; border: 1px solid black; padding: 2px;">&times;</button>
                                                                <h4 class="modal-title" style="color:#0e3c90; text-align: center;">Order Notes</h4><br>
                                                                <div style="text-align:center;"><i>Warehouse Manager Notes</i></div>
                                                            </div>
                                                            <div class="modal-body" style="font-size: 14px; height:fit-content; overflow:auto;">
                                                                <form action="" method="post">
                                                                    <input type="hidden" name="order_id" value="'.$row1['id'].'">
                                                                    <div class="form-group custModal">
                                                                        <div class="col-sm-6" style="padding-top:6px;">
                                                                                <input type="hidden" name="china_code" value="'.$row1['product_china_code'].'">
                                                                                '.$chatz.'
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group custModal">
                                                                        <div class="col-sm-6" style="padding-top:6px; display:flex;">
                                                                                <input type="text" name="order_notes" class="form-control custInput2">
                                                                                <button type="submit" class="btn btn-info copy_btn custBtn" value="Update" name="form3" style="margin-top:0px">Update</button>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>';
                                    }
                                ?>
                            </td>
                            <td>
                                <?php
                                    if($row1['product_china_code'] != ""){
                                                        $status = json_decode($row1['product_shipping_status'],true);
                                                        echo '<a href="#" class="btn btn-success btn-xs" style="width:100%;margin-bottom:4px;" data-toggle="modal" data-target="#myShippingModal'.$row1['id'].'">Edit</a>
                                                            <div id="myShippingModal'.$row1['id'].'" class="modal fade" role="dialog">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content" style="border: 2px solid #352121ba; margin-top: 100px; border-radius: 15px;">
                                                                        <div class="modal-header">
                                                                            <button type="button" class="close" data-dismiss="modal" style="opacity: 1; color: #a71e1e; font-weight: 500; border-radius: 50%; border: 1px solid black; padding: 2px;">&times;</button>
                                                                            <h4 class="modal-title" style="color:#0e3c90; text-align: center;">Update Shipping Information</h4><br>
                                                                            <div style="text-align:center;"><i style="text-align:centered;">Product Tracking Code is <b>'.$row1['product_site_track'].'</b></i></div>
                                                                        </div>
                                                                        <div class="modal-body custModalBody" style="font-size: 14px">
                                                                            <form action="shipping-change-status.php" method="post">
                                                                                <input type="hidden" name="order_id" value="'.$row1['id'].'">
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_0" value="'.$status[0].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_1" value="'.$status[1].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_2" value="'.$status[2].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_3" value="'.$status[3].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_4" value="'.$status[4].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_5" value="'.$status[5].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_6" value="'.$status[6].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_7" value="'.$status[7].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_8" value="'.$status[8].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <input type="text" name="shippping_status_9" value="'.$status[9].'" class="form-control custInput">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group custModal">
                                                                                    <div class="col-sm-6" style="padding-top:6px;">
                                                                                            <button type="submit" class="btn btn-info copy_btn custBtn" value="Update" name="form3">Update</button>
                                                                                    </div>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>';
                                 }
                                ?>
                            </td>
    	                    <td style="vertical-align: middle;">
                                <a href="#" class="btn btn-danger btn-xs" data-href="order-delete.php?ty=unique&id=<?php echo $row1['id']; ?>&vid=<?php echo $_GET['id']; ?>" data-toggle="modal" data-target="#confirm-delete" style="width:100%;">Delete</a>
    	                    </td>
    	                </tr>
            		<?php  }} ?>
            </tbody>
          </table>
        </div>
      </div>
  

</section>


<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
            </div>
            <div class="modal-body">
                Are you sure want to delete this item?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger btn-ok">Delete</a>
            </div>
        </div>
    </div>
</div>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
    
    function viewMark(did){
        
		let dataString = 'nid=' + did;

        // AJAX code to submit form.
        $.ajax({
            type: "POST",
            url: "note-update",
            data: dataString,
            cache: false,
            success: function(data) {
                //alert('messsage read '+data);
            },
            error: function (errorThrown) { /**alert('messsage error '+JSON.stringify(errorThrown));**/ }
        });
        
    }
</script>
<?php require_once('footer.php'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/notify.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>
<script>
    var clipboard = new ClipboardJS('.copy_btn');
    clipboard.on('success', function(e) {
        let trigg = e.trigger.getAttribute('id');
        $('#'+trigg).notify("Copied", 'success');
        e.clearSelection();
    });

    clipboard.on('error', function(e) {
        let trigg = e.trigger.getAttribute('id');
        $('#'+trigg).notify("Not Copied", 'error');
        e.clearSelection();
    });
</script>