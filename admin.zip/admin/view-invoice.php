<?php require_once('header.php'); ?>

<?php
    if(!isset($_REQUEST['id'])) {
      header('location: logout.php');
      exit;
    } else {
        // Check the id is valid or not
        $statement = $pdo->prepare("SELECT * FROM tbl_payment WHERE id=?");
        $statement->execute(array($_REQUEST['id']));
        $total = $statement->rowCount();
        if( $total == 0 ) {
          header('location: logout.php');
          exit;
        } else {
          $id = $_REQUEST['id'];
          $result = $statement->fetchAll(PDO::FETCH_ASSOC);             
          foreach ($result as $row) {
            $cust_id = $row['customer_id'];
            $cust_name = $row['customer_name'];
            $cust_email = $row['customer_email'];
            $cust_date1 = date('d/m/Y', strtotime($row['payment_date']));
            $cust_date2 = date('d/m/Y h:i:s A', strtotime($row['payment_date']));
            $cust_amount = $row['paid_amount'];
            $cust_shipping = $row['paid_shipping'];
            $cust_commission = $row['paid_commission'];
            $cust_method = ucfirst($row['payment_method']);
            $cust_payment_id = $row['payment_id'];
            $cust_txn_id = $row['txnid'];
          }

          $statement = $pdo->prepare("SELECT * FROM tbl_order WHERE payment_id=?");
          $statement->execute(array($cust_payment_id));
          $result= $statement->fetchAll(PDO::FETCH_ASSOC);   
          $order_price_total = 0;   
          $tableData = "";                     
          foreach ($result as $row) {
              $order_name = $row['product_name'];
              $order_link = $row['product_link'];
              $order_quantity = $row['quantity'];
              $order_price = $row['unit_price'] * $order_quantity;
              $order_price_total += (int)$order_price;
              $tableData .= '
                  <tr>
                    <td>'.$order_quantity.'</td>
                    <td>'.$order_name.'</td>
                    <td>'.$order_link.'</td>
                    <td>'.$order_price.'</td>
                  </tr>';
          }
        }
    }
?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        View Invoice
      </h1>
    </section>

    <!-- Main content -->
     <!-- Main content -->
        <section class="invoice">
          <!-- title row -->
          <div class="row">
            <div class="col-xs-12">
              <h2 class="page-header">
                <i class="fa fa-globe"></i> <?php echo $site_name; ?>.
                <small class="pull-right">Date: <?php echo $cust_date1; ?></small>
              </h2>
            </div><!-- /.col -->
          </div>
          <!-- info row -->
          <div class="row invoice-info">
            <div class="col-sm-4 invoice-col">
              From
              <address>
                <strong><?php echo $site_name; ?>.</strong><br>
                <?php echo $site_address; ?><br>
                Phone: <?php echo $site_phone; ?><br>
                Email: <?php echo $site_email; ?>
              </address>
            </div><!-- /.col -->
            <div class="col-sm-4 invoice-col">
              To
              <address>
                <strong><?php echo $cust_name; ?></strong><br>
                Id: <?php echo $cust_id; ?><br>
                Email: <?php echo $cust_email; ?>
              </address>
            </div><!-- /.col -->
            <div class="col-sm-4 invoice-col">
              <b>Invoice #<?php echo $cust_payment_id ?></b><br>
              <br>
              <b>Txn ID:</b> <?php echo $cust_txn_id ?><br>
              <b>Payment Due:</b> <?php echo $cust_date2; ?><br>
              <b>Account:</b> <?php echo $cust_id; ?>
            </div><!-- /.col -->
          </div><!-- /.row -->

          <!-- Table row -->
          <div class="row">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Qty</th>
                    <th>Product</th>
                    <th>Description</th>
                    <th>Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  <?php echo $tableData; ?>
                </tbody>
              </table>
            </div><!-- /.col -->
          </div><!-- /.row -->

          <div class="row">
            <!-- accepted payments column -->
            <div class="col-xs-6">
              <p class="lead">Payment Methods:</p>
              <img src="../assets/img/visa.png" alt="Visa">
              <img src="../assets/img/mastercard.png" alt="Mastercard">
              <img src="../assets/img/american-express.png" alt="American Express">
              <img src="../assets/img/paypal.png" alt="Paypal">
              <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                PAID WITH : <?php echo $cust_method; ?>
              </p>
            </div><!-- /.col -->
            <div class="col-xs-6">
              <p class="lead">Amount PAID <?php echo date('d/m/Y h:i:s A',time()); ?></p>
              <div class="table-responsive">
                <table class="table">
                  <tr>
                    <th style="width:50%">Subtotal:</th>
                    <td><?php echo $site_currency.' '.number_format($order_price_total,2); ?></td>
                  </tr>
                  <tr>
                    <th>Tax (0%)</th>
                    <td><?php echo $site_currency.' 0.00'; ?></td>
                  </tr>
                  <tr>
                    <th>Shipping:</th>
                    <td><?php echo $site_currency.' '.number_format($cust_shipping,2); ?></td>
                  </tr>
                  <tr>
                    <th>Commission:</th>
                    <td><?php echo $site_currency.' '.number_format($cust_commission,2); ?></td>
                  </tr>
                  <tr>
                    <th>Total:</th>
                    <td><?php echo $site_currency.' '.number_format($cust_amount,2); ?></td>
                  </tr>
                </table>
              </div>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->

<?php require_once('footer.php'); ?>